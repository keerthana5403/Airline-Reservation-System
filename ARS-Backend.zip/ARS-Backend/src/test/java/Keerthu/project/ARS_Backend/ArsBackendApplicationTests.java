package Keerthu.project.ARS_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
